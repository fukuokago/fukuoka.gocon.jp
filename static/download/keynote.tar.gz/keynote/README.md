Go Conference'19 Keynote Theme
==

テーマを追加する前に同梱のフォントをインストールしてください

- Mac でフォントをインストール／削除する方法  
  https://support.apple.com/ja-jp/HT201749
